def rec_sum(arr):
    if len(arr)==0:
        #print(s)
        return 0
    if len(arr)==1:
        return arr[0]
    if len(arr)==2:
        return max(arr)
    t=arr[0]+rec_sum(arr[2:])
    t1=arr[1]+rec_sum(arr[3:])
    return max(t,t1)
        




arr=[13,9,4,10,5,7]
print(rec_sum(arr))

