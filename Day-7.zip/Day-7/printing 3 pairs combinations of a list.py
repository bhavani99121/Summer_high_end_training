'''def three_comb(li,i,j,k):
    if k<len(li) and i<j<k:
        print(li[i],li[j],li[k])
        k=k+1
        three_comb(li,i,j,k)
    elif k==len(li) and i<j<k:
        if j<len(li)-2:
            j=j+1
            k=j+1
            three_comb(li,i,j,k)
        else:
            i=i+1
            j=i+1
            k=j+1
            three_comb(li,i,j,k)
    
    
li=[3,2,5,4,1,6,8]
three_comb(li,0,1,2)'''
def three_comb(li,k,curr,start):
    if len(curr)==k:
        print(curr)
        return
    for i in range(start,len(li)):
        three_comb(li,3,curr+[li[i]],i+1)
li=[3,2,5,4,1,6,8]
three_comb(li,3,[],0)
