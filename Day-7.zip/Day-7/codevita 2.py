n=int(input())
s=""
li=[]
for i in range(n):
    ao=input()
    cs=input()
    for i in ao:
        if i in cs:
            s=s+i*cs.count(i)
    print(s)
    s=""
    n=n-1
            
       


