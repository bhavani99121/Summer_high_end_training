s="teacher"
num=int(input())
li=[]
for i in range(num):
    n=input()
    li.append(n)
li1=[]
for i in li:
        li1.append(int(i[-1]))
prefix=""
suffix=""
l2=[]
for i in li1:
    suffix=s[i:]
    prefix=s[:i]
    for j in li:
        if j[0]=='l':
                    l2.append(suffix+prefix)
                    break
        elif j[0]=='r':
                    l2.append(prefix+suffix)
                    break
s1=''
for i in l2:
    s1=s1+i[0]
print(s1)#hoc
substrings=[]
for i in range(len(s)-num+1):
    substrings.append(s[i:i+num])
print(substrings)
'''for i in substrings:
    sorted(i)'''
#print(substrings)
s1=sorted(s1)
s2=""
s2="".join(s1)
print(s2)
for i in substrings:
    if s2==i:
        print("true")
        break
else:
    print("false")
      


    

