q=4
li=[]
c=0
"1-add word,2-search for word,3-search prefix"
for i in range(q):
    n=input()
    w=n[1:]
    if n[0]=='1':
            li.append(w)
    elif n[0]=='2':
            if w in li:
                print(True)
            else:
                print(False)
    elif n[0]=='3':
            l3=[]
            c1=0
            l=len(n[1:])
            for k in li:
                if n[1:]==k[:l] and k not in l3:
                    c1=c1+1
                    l3.append(k)
            print(c1)
            if c1!=0:
                  print(True)
            else:
                  print(False)
    elif n[0]=='4':
        for i in li:
            if n[1:]==i:
                li.remove(i)
        print(li)
            



        
  