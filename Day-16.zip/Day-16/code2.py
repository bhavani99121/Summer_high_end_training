class trie:
    def __init__(self):
        self.d={}
        self.flag=0
class tries:
    def __init__(self):
        self.root=trie()
    def insert(self,st):
        t=self.root
        for i in st:
            if i not in t.d:#checking char is present in trie or not
                t.d[i]=trie()#placing char in trie and creating reference
            t=t.d[i]
        t.flag=1
    def search(self,st):
        t=self.root
        for i in st:
            if i not in t.d:
                return False
            t=t.d[i]
        if t.flag==1:
            return True
        else:
            return False
    def search_prefix(self,st):
        t=self.root
        for i in st:
            if i not in t.d:
                return False
            t=t.d[i]
        return True
    def subprefixes(self,st):
        def dfs(t,s):
            if t.flag==1:
                print(s)
            for i in t.d:
                dfs(t.d[i],s+i)
        t=self.root
        s1=""
        for i in st:
            if i in t.d:
               s1=s1+i
               t=t.d[i]
            else:
                return 
        dfs(t,s)
              

   
t1=tries()
n=int(input())
for i in range(n):
    a,s=input().split()
    if a=='1':
        t1.insert(s)
    elif a=='2':
        if t1.search(s):
            print("Found")
        else:
            print("Not found")
    elif a=='3':
        if t1.search_prefix(s):
            print("Found")
        else:
            print("Not found")
    elif a=='4':
        t1.subprefixes(s) #printing all strings that starts with s
#input=1 world
#1 word
#1 apple
#4 wo


