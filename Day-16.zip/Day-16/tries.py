class trie:
    def __init__(self):
        self.d={}
        self.flag=0
class tries:
    def __init__(self):
        self.root=trie()
    def insert(self,st):
        t=self.root
        for i in st:
            if i not in t.d:#checking char is present in trie or not
                t.d[i]=trie()#placing char in trie and creating reference
            t=t.d[i]
        t.flag=1
    def search(self,st):
        t=self.root
        for i in st:
            if i not in t.d:
                return False
            t=t.d[i]
        if t.flag==1:
            return True
        else:
            return False
    def search_prefix(self,st):
        t=self.root
        for i in st:
            if i not in t.d:
                return False
            t=t.d[i]
        return True
   



t1=tries()
t1.insert("word")
t1.insert("world")
t1.insert("words")
t1.insert("apple")
t1.insert("woo")
t1.insert("wo")
if t1.search("wo"):
    print("Found")
else:
    print("Not found")
if t1.search_prefix("wox"):
    print("Found")
else:
    print("Not found")
