s="abbbacabbra"

