def visiting_nodes(dic,v,e,stack,c,t,m):
    stack.append(v)
    if v==e:
        if c<m:
            m=c
            t=stack[:]
        stack.pop()
        return (t,m)
    for i,j in dic[v]:
        if i not in stack:
            (t,m)=visiting_nodes(dic,i,e,stack,c+j,t,m)
    stack.pop()
    return (t,m)
   
dic={5:[(3,8),(7,1)],7:[(3,6),(4,2),(5,1)],4:[(2,3),(7,2),(8,5)],8:[(2,4),(3,7),(4,5)],3:[(5,8),(7,6),(8,7)],2:[(4,3),(8,4)]}
stack=[]
t=[]
for i in dic.keys():
    print(visiting_nodes(dic,5,i,stack,0,t,10000)) 

