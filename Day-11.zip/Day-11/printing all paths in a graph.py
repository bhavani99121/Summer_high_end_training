def visiting_nodes(dic,v,stack):
    stack.append(v)
    if v==2:
        print(stack)
    for i in dic[v]:
        if i not in stack:
            visiting_nodes(dic,i,stack)
    stack.pop()
        
            
        

dic={5:[3,7],7:[3,4,5],4:[2,7,8],8:[2,3,4],3:[5,7,8],2:[4,8]}
stack=[]
visiting_nodes(dic,5,stack)



