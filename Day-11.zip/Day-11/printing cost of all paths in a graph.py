def visiting_nodes(dic,v,stack,c):
    stack.append(v)
    print(stack,c)
    for i,j in dic[v]:
        if i not in stack:
            visiting_nodes(dic,i,stack,c+j)
    stack.pop()
        
            
        

dic={5:[(3,8),(7,1)],7:[(3,6),(4,2),(5,1)],4:[(2,3),(7,2),(8,5)],8:[(2,4),(3,7),(4,5)],3:[(5,8),(7,6),(8,7)],2:[(4,3),(8,4)]}
stack=[]
visiting_nodes(dic,5,stack,0)




