ip=list(map(int,input().split(" ")))
sp=0
bp=ip[0]
for i in range(1,len(ip)):
    if ip[i]<bp:
        bp=ip[i]
    else:
        sp=ip[i]-bp
print(bp,sp)
    