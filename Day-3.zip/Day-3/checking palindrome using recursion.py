def  checkpalindrome(n,s):
    if n==0:
        return s
    num=n
    r=num%10
    s=s*10+r
    return checkpalindrome(num//10,s)

n=int(input())
t=checkpalindrome(n,0)
if t==n:
    print("palindrome")
else:
    print("not palindrome")
