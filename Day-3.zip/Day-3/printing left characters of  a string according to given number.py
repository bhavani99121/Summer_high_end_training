ch=input()
s=int(input())
ans=s%26
a=''
for i in ch:
    if (ord(i)-ans)<97:
        a=a+chr((ord(i)-ans+26))
        
    else:
        a=a+chr((ord(i)-ans))
print(a)
