n=int(input())
ma=[]
for i in range(n):
    cr=input()
    ma.append(cr)
s=input()
le=len(s)
j=0
i=0
c=0
while i<n and j<len(s):
    if s[j] in ma[i]:
        c=c+1
        j=j+1
        i=i+1
    else:
        print("false")
        break
    if i==n:
        i=0
if c==le:
    print("true")