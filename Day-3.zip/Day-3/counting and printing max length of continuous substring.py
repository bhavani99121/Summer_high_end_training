ip='abcde'
co=1
ma=0
i=0
j=i+1
while i<=j and j<len(ip):
        c=ord(ip[i])
        m=ord(ip[j])
        if c+1==m:
            co=co+1
            i=i+1
            j=i+1
        else:
            if ma<=co:
                ma=co
            co=1
            i=i+1
            j=i+1
        if co>ma:
            ma=co
print(ma)
                