n=input()
li=''
l=''
l1=''
l2=''
l3=''
l4=''
lv=['a','e','i','o','u']
uv=['A','E','I','O','U']
num=['0','1','2','3','4','5','6','7','8','9']
for i in n:
    if i in num:
        li=li+i
    elif i in lv:
        l=l+i
    elif i in uv:
        l1=l1+i
    elif i not in lv:
        l2=l2+i
    elif i not in uv:
        l3=l3+i
    else:
        l4=l4+i
print(len(li))
print(len(l))
print(len(l1))
print(len(l2))
print(len(l3))
print(len(l4))
