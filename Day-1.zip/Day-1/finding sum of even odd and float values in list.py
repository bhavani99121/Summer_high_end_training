n=[5,3,7,5.6,4,2.2,3]
s,s1,s2=0,0,0
for i in n:
    if int(i)==i and i%2==0:
        s=s+i
    elif int(i)==i and i%2!=0:
        s1=s1+i
    else:
        s2=s2+i
print(s,s1,s2)


