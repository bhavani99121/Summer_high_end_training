def prime(n): 
 c=0
 for i in range(2,(n//2)+1):
     if n%i==0:
         c=c+1
         break
 if c==0:
     print(n)
 else:
     prime(n+1)
n=int(input())
prime(n)

            