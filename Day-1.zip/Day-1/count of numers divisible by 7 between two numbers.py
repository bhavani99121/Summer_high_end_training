i1=int(input())
i2=int(input())
s=(i2-i1)//7
print("count:",s)

