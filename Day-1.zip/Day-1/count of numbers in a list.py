li=list(map(int,input().split(",")))
li1=[]
for i in li:
    if(i not in li1):
        li1.append(i)
for i in li1:
    print(i,'-',li.count(i))