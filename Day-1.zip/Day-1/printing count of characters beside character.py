l="aaabccaadddd"
i=0
s=""
c1=""
c=1
while(i<len(l)-1):
    if l[i]==l[i+1]:
        c=c+1
        i=i+1
        
    else:
        s=s+l[i]+str(c)
        c=1
        i=i+1
s=s+l[-1]+str(c)#can use i+1 in place of -1
print(s)
        
         
        

        
    
