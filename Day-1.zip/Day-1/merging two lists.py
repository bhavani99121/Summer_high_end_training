#two lists sorted with diff lengths and merge those lists in ascending order
l1=list(map(int,input().split(",")))
l2=list(map(int,input().split(",")))
l3=[]
#logic1
'''l3=l1+l2
l3.sort()
print(l3)'''

#logic2
i=0
j=0
while(i<len(l1) and j<len(l2)):
        if l1[i]<l2[j]:
            l3.append(l1[i])
            i=i+1
        else:
            l3.append(l2[j])
            j=j+1
while(j<len(l2)):
    l3.append(l2[j])
    j=j+1
while(i<len(l1)):
    l3.append(l1[i])
    i=i+1
print(l3,len(l3))
v=len(l3)//2

if len(l3)%2!=0:
        print(l3[v])
else:
        v1=(l3[v]+l3[v-1])/2
        print(v1)
