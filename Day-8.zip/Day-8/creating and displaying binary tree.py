class Node:
    def __init__(self,data):
        self.data=data
        self.left=None
        self.right=None
class Binary_tree:
    def create_node(self,data):
        return Node(data)
    def insert(self,node,data):
        if node is None:
            return self.create_node(data)
        if data<node.data:
            node.left=self.insert(node.left,data)
        else:
            node.right=self.insert(node.right,data)
        return node
    def display_inorder(self,root):
        if root is not None:
            self.display_inorder(root.left)
            print(root.data,end="->")
            self.display_inorder(root.right)
    def display_preorder(self,root):
        if root is not None:
            print(root.data,end="->")
            self.display_preorder(root.left)
            self.display_preorder(root.right)
    def display_postorder(self,root):
        if root is not None:
            self.display_postorder(root.left)
            self.display_postorder(root.right)
            print(root.data,end="->")
            
tree=Binary_tree()
root=tree.create_node(10)
print("root node:",root.data)
tree.insert(root,5)
tree.insert(root,1)
tree.insert(root,7)
tree.insert(root,6)
tree.insert(root,8)
tree.insert(root,20)
tree.insert(root,25)
tree.display_inorder(root)
print()
tree.display_preorder(root)
print()
tree.display_postorder(root)