s1="the quick brown fox jumps over the lazy dog"
s2="khffnlskm"
s3="qwweer yuiop asdfvgh jkl mnblkjcxz"
s=set(s1)
if len(s)==27:
    print(True)
else:
    print(False)
        
    