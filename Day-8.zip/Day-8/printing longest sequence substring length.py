s="abcdeeghijklmn"
s1=""
m=0
st=0
dic={}
while(st<len(s)):
    for i in range(st,len(s)):
        if s[i] not in s1:
            s1=s1+s[i]
            dic[s[i]]=i
        else:
            if m<len(s1):
                m=len(s1)
            s1=""
            st=dic[s[i]]+1
            break
print(m)