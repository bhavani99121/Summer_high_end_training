#li=[1,2,3,4,1,2,3,1,2]
li=[2,3,1,3,4,3,2]
#li=[4,5,2,1]
c=0
matrix=[]
while(c!=len(li)):
    li1=[]
    for i in range(len(li)):
        if li[i]!=-1:
            if li[i] not in li1:
                c=c+1
                li1.append(li[i])
                li[i]=-1
    matrix.append(li1)
print(matrix)
    
    