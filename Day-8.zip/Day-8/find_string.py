def find_string(matrix,s,r,c,n,k,t):
    if k==len(s):
        return 1
    if r<0 or c<0 or r>=n or c>=n:
        return 
    if matrix[i][j]==s[k]:
        matrix[i][j]=0
        t=find_string(matrix,r-1,c,k+1)
        t=find_string(matrix,r,c+1,n,k+1)
        t=find_string(matrix,r+1,c,n,k+1)
        t=find_string(matrix,r,c-1,n,k+1)
        return t
    

        

n="word"
matrix=[]
for i in range(len(n)):
    li=[]
    for j in range(len(n)):
        inp=input()
        li.append(inp)
    matrix.append(li)
for i in range(len(matrix)):
    for j in range(len(matrix)):
        if matrix[i][j]=="w":
            c=find_string(matrix,s,i,j,n,1,0)
            if c==1:
                print("yes")
                break
if c==0:
    print(False)


                    
                    



