#printing leaf nodes
class Node:
    def __init__(self,data):
        self.data=data
        self.left=None
        self.right=None
class Binary_tree:
    def create_node(self,data):
        return Node(data)
    def insert(self,node,data):
        if node is None:
            return self.create_node(data)
        if data<node.data:
            node.left=self.insert(node.left,data)
        else:
            node.right=self.insert(node.right,data)
        return node
    def search_ele(self,root,se):
        if root is None:
            return 0
        if root.data==se:
            return 1
        elif se>root.data:
            return self.search_ele(root.right,se)
        elif se<root.data:
            return self.search_ele(root.left,se)
    def depth(self,root,se,c):
        if root is None:
            return -1
        if root.data==se:
            return c
        elif root.data>se:
            return self.depth(root.left,se,c+1)
        elif root.data<se:
            return self.depth(root.right,se,c+1)
        
        
tree=Binary_tree()
root=tree.create_node(10)
#print("root node:",root.data)
tree.insert(root,20)
tree.insert(root,5)
tree.insert(root,2)
tree.insert(root,40)
tree.insert(root,12)
se=int(input("enter search element/depth element:"))
s=tree.search_ele(root,se)
if s==1:
    #print("found")
    print(tree.depth(root,se,0))
else:
    print("Not found")
#print(tree.display_sumofleafnodes(root))


