s1="the 4quick br@$^own fox jumps over the lazy dog"
#d={}#d=set()
d=[0]*26
for i in s1:
    if i.islower():
            #d[i]=1#d.add(i)
            d[ord(i)-97]+=1
print(all(d))
    