s1="th@e 4quick brAown fox jumps oBver the la.zy dog"
s2="the 4quick br@$^own fox jumps over the lazy dog"
s4="gfhsdueefen345678suyd!@#$%^&*"
c=0
s=""
for i in s4:
    if i.islower():
        s=s+i
s3=set(s)
if len(s3)==26:
    print(True)
else:
    print(False)