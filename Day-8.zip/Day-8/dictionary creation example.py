li=[1,2,3,4,1,2,3,1,2]
for i in li:
    if i not in dic:
        dic[i]=1
    else:
        dic[i]+=1
