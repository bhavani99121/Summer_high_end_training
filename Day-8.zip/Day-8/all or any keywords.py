a=[6,7,8,9]
print(all(a))#all return true when there is no zero
b=[8,5,9,0]
print(all(b))