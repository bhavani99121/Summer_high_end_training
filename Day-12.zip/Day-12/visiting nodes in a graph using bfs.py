di={1:[5],5:[3,7,1],7:[5,9,4],4:[2,7,8],8:[3,4],3:[5,8,6],2:[4],6:[3],9:[7]}
queue=[]
s=5
queue.append(s)
v=[]
while queue:
    for i in di[queue[0]]:
        if i not in queue  and i not in v:
            queue.append(i)
    if queue[0] not in v:
        v.append(queue[0])
    queue.pop(0)

print(v)
        
        
                
