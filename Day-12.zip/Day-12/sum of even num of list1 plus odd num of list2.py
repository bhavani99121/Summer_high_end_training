def sumofeven_odd(li1,li2,li3,i,j):
    if i==len(li1):
        return li3
    if j==len(li2):
        return sumofeven_odd(li1,li2,li3,i+1,0) 
    s=0
    if li1[i]%2==0 :
        if li2[j]%2!=0:
                s=li1[i]+li2[j]
                li3.append(s)
                
        return sumofeven_odd(li1,li2,li3,i,j+1)
    else:
            return sumofeven_odd(li1,li2,li3,i+1,j)




li1=[6,3,2,9,4,7]
li2=[8,7,5,3,6,9]
li3=[]
print(sumofeven_odd(li1,li2,li3,0,0))