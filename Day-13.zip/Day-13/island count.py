def island(matrix,r,c,n,c1):
    if r<0 or c<0 or r>=n or c>=n or matrix[r][c]!=1:
        return c1
    if matrix[r][c]==1:
        matrix[r][c]=2
        c1=c1+1
        c1=island(matrix,r-1,c,n,c1)
        c1=island(matrix,r,c+1,n,c1)
        c1=island(matrix,r+1,c,n,c1)
        c1=island(matrix,r,c-1,n,c1)
    return c1
        
n=int(input())
matrix=[]
for i in range(n):
    li=[]
    for j in range(n):
        inp=int(input())
        li.append(inp)
    matrix.append(li)
c=0
ma=0
for i in range(len(matrix)):
    for j in range(len(matrix)):
        if matrix[i][j]==1:
            p=island(matrix,i,j,n,0)
            if p>ma:
                ma=p
            c=c+1
print(matrix)
print("no of islands and maximum area:",c,"and",ma)


                    
                    



