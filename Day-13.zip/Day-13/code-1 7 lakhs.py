timings=[(1,3),(2,5),(4,6),(6,7),(5,8),(7,9)]
cost=[5,6,5,4,11,2]
u_cost=[5,6,5,4,11,2]
i=0
k=1
for i in range(1,len(timings)):
    for j in range(0,i):
        if timings[j][1]<=timings[i][0]:
            if u_cost[j]<u_cost[j]+cost[i]:
                u_cost[i]=u_cost[j]+cost[i]
            
print(max(u_cost))
            
        