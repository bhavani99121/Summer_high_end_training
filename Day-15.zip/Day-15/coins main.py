c=[2,3,5,6]
v=11
l1=[0]*(v+1)
l1[0]=1
l2=l1[:]
for i in c:
    l1=l2[:]
    for j in range(i,v+1):
            c=j-i
            l2[j]=max(l1[c],l1[j])
    
print(l2)
            
        
        
