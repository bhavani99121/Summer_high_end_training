h=[11,5,9,6,8,10]
c1=1
c2=1
m=h[0]
for i in range(1,len(h)):
    if m<h[i]:
        c1=c1+1
        m=h[i]
m=h[-1]
for i in range(len(h)-1,-1,-1):
    if m<h[i]:
        c2=c2+1
        m=h[i]
print(c1,c2)