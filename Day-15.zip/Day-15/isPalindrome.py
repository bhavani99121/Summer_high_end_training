def palin(n):
    if ispalin(n):
        print(int(n))
    else:
        v=len(n)//2
        if len(n)%2==0:
            s=""
            left_=n[:v]
            s=int(left_+left_[::-1])
            if s>int(n):
                print(s)
            else:
                left_=str(int(n[:v])+1)
                s=int(left_+left_[::-1])  
                print(s)
        else:
            left_=n[:v]
            m=n[v]
            s=int(left_+m+left_[::-1])
            if s>int(n):
                print(s)
            else:
                if int(m)==9:
                    left_=str(int(left_)+1)
                    s=int(left_+"0"+left_[::-1])
                    print(s)
                    
                else:
                    m_=str(int(m)+1)
                    s=int(left_+m_+left_[::-1])
                    print(s)
                    
               

           
           

def ispalin(n):
    s=int(n)
    s2=s
    s1=0
    while s>0:
        r=s%10
        s1=s1*10+r
        s=s//10
    if s1==s2:
        return True
    else:
        return False


n=input()
palin(n)