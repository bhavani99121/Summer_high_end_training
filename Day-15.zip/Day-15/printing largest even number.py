s1="tu7956gkh"
s2="gggd10h11i12m16h"
l=[]
e=[]
o=[]
for i in s1:
    if i.isdigit() and i not in l:
        l.append(i)
        if int(i)%2==0:
            e.append(int(i))
        else:
            o.append(int(i))
for i in s2:
    if i.isdigit() and i not in l:
        l.append(i)
        if int(i)%2==0:
            e.append(int(i))
        else:
            o.append(int(i))
e.sort()
o.sort(reverse=True)
#print(e,o)
v=e[0]
if len(e)==1:
    o.append(v)
    print(''.join(map(str,o)))
else:
    e.remove(v)
    e.sort(reverse=True)
    i=0
    j=0
    li=[]
    while i<len(e) and j<len(o):
        if e[i]>o[j]:
            li.append(e[i])
            i=i+1
        else:
            li.append(o[j])
            j=j+1
    while i<len(e):
        li.append(e[i])
        i=i+1
    while j<len(o):
        li.append(o[j])
        j=j+1
    li.append(v)
    print(''.join(map(str,li)))