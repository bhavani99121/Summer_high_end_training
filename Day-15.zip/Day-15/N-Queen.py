def Nqueen(board,r,r1,c1):
    n=len(board)
    if r==len(board):
        return True
    for c in range(len(board)):
        if issafe(board,r,c,r1,c1):
            board[r][c]='Q'
            if Nqueen(board,r+1,r1,c1):
                return True
            board[r][c]='-'
    return False
    
def issafe(board,r,c,r1,c1):
    #checking column
    for i in range(r):
        if board[i][c]=="Q":
            return False
    #checking'/' diagonal
    i,j=r,c
    while i>=0 and j<len(board):
        if board[i][j]=="Q":
            return False
        i=i-1
        j=j+1
    #checking '\' diagonal
    i,j=r,c
    while i>=0 and j>=0:
        if board[i][j]=="Q":
            return False
        i=i-1
        j=j-1
    
    return True


n=int(input("enter number of queens:"))
board=[['-' for i in range(n)] for j in range(n)]
r1,c1=4,4
if Nqueen(board,0,r1,c1):
    for i in board:
        print("".join(i))
else:
    print("NO")