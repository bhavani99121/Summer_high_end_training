li=[4,2,4,4,8,8]
i=li[0]
c=1
j=1
while j<len(li):
    if li[j]==i:
        c=c+1
    else:
        if c==0:
            i=li[j]
            c=1
        else:
            c=c-1
    j=j+1
print(i)
    
    
    
    
  
    

        