class node:
    def __init__(self,data):
        self.data=data
        self.next=None
        self.prev=None
class dll:
    def __init__(self):
        self.head=None
        self.tail=None
    def addend(self,x):
        if(self.head==None):
            self.head=node(x)
            self.tail=self.head
        else:
            t=node(x)
            self.tail.next=t
            t.prev=self.tail
            self.tail=t
    def addbeg(self,x):
        if self.head is None:
            self.head=node(x)
            self.tail=self.head
        else:
            newnode=node(x)
            newnode.next=self.head
            self.head.prev=newnode
            newnode.prev=None
            self.head=newnode
    def check_parenthesis(self):
        li=[]
        t1=self.head
        k=0
        c=0
        while t1!=None:
            if t1.data=="{" or t1.data=="[" or t1.data=="(":
                li.append(t1.data)
                c=c+1
            elif li:
                if t1.data=="}" and li[-1]=="{"  or t1.data=="]" and li[-1]=="[" or t1.data==")" and li[-1]=="(":
                    li.pop()
                    c=c+1
                
                else:
                    print(c)
                    break
            elif not li:
                print(1)
            t1=t1.next
        if len(li)==0:
            print(-1)
            
            
        
    def display(self):
        temp=self.head
        print("forward direction")
        while temp:
                print(temp.data,end=" ")
                if temp.next is not None:
                    print("<->",end=" ")
                temp=temp.next
        print()
        
ll=dll()
s='}{}()'
for i in s:
    ll.addend(i)
ll.check_parenthesis()
ll.display()

        
    





