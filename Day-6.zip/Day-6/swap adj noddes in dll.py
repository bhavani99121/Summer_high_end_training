class node:
    def __init__(self,data):
        self.data=data
        self.next=None
        self.prev=None
class dll:
    def __init__(self):
        self.head=None
        self.tail=None
    def addend(self,x):
        if(self.head==None):
            self.head=node(x)
            self.tail=self.head
        else:
            t=node(x)
            self.tail.next=t
            t.prev=self.tail
            self.tail=t
    def addbeg(self,x):
        if self.head is None:
            self.head=node(x)
            self.tail=self.head
        else:
            newnode=node(x)
            newnode.next=self.head
            self.head.prev=newnode
            newnode.prev=None
            self.head=newnode
    def swap_adj(self):
        t1=self.head
        t2=t1.next
        t3=None
        while t1.next!=None and t2.next!=None:
            if t1==self.head:
                t1.next=t2.next
                t2.next=t1
                t2.prev=t3
                t1.prev=t2
                self.head=t2
                t1,t2=t2,t1
                t3=t2
            else:
                t1.next=t2.next
                t2.next=t1
                t2.prev=t3
                t1.prev=t2
                t3.next=t2
                t1,t2=t2,t1
                t3=t2
            t1=t1.next.next
            t2=t2.next.next
    def display(self):
        temp=self.head
        print("forward direction")
        while temp:
                print(temp.data,end=" ")
                if temp.next is not None:
                    print("<->",end=" ")
                temp=temp.next
        print()
        '''print("backward direction")
        temp=self.tail
        while temp!=None:
            print(temp.data,end=" ")
            if temp.prev is not None:
                print("<->",end=" ")
            temp=temp.prev
        print()'''
ll=dll()
ll.addend(5)
ll.addend(7)
ll.addend(8)
ll.addend(2)
ll.addend(1)
ll.addend(4)
#ll.addend(12)
#ll.addend(15)
ll.display()
ll.swap_adj()
ll.display()

        
    




