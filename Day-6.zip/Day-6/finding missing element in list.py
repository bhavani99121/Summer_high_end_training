n=7
li=[0,5,3,6,4,2,1]
s=sum(li)
n=(n*(n+1))//2
print(n-s)
    