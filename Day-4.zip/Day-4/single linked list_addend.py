class node:
    def __init__(self,u):
        self.data=u
        self.next=None
class sll:
    def __init__(self):
        self.head=None
    def add_end(self,v):
        t=self.head
        while t.next!=None:
            t=t.next
        t.next=node(v)
    def add_beg(self,u):
        Newnode=node(u)
        t=self.head
        Newnode.next=t
        self.head=Newnode
    '''def even_sum(self):
        temp=self.head
        while temp.next is not None:
            s=0
            if temp.data%2==0:
                s=s+temp.data
                temp=temp.next
            print("even sum:",s)'''
        
    def display(self):
        t=self.head
        s=0
        while(t!=None):
            print(t.data,end='->')
            s=s+t.data
            t=t.next
        print("sum:",s)
        
l1=sll()
l1.head=node(10)
l1.add_end(20)
l1.add_end(30)
l1.display()
l1.add_beg(234)
l1.add_end(456)
l1.display()
l1.add_beg(134)
l1.display()
l1.even_sum()
l2=sll()
l2.head=node(100)
l2.add_end(200)
l2.add_end(300)
l2.display()



'''print(head.data)
print(head.next.data)
print(head.next.next.data)'''

