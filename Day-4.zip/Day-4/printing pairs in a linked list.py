class node:
    def __init__(self,u):
        self.data=u
        self.next=None
class sll:
    def __init__(self):
        self.head=None
    def add_end(self,v):
        t=self.head
        while t.next!=None:
            t=t.next
        t.next=node(v)
    def add_beg(self,u):
        Newnode=node(u)
        t=self.head
        Newnode.next=t
        self.head=Newnode
    def pairs(self):
        t1=self.head
        t2=t1.next
        while t1.next!=None:
            if t2 is not None:
                print(t1.data,t2.data)
                t2=t2.next
            else:
                t1=t1.next
                t2=t1.next
            
    def display(self):
        t=self.head
        s=0
        while(t!=None):
            print(t.data,end='->')
            s=s+t.data
            t=t.next
        print("sum:",s)
        
l1=sll()
l1.head=node(10)
l1.add_end(11)
l1.add_end(12)
l1.display()
l1.add_beg(234)
l1.add_end(456)
l1.display()
l1.add_beg(134)
l1.display()
l1.pairs()








