class node:
    def __init__(self,u):
        self.data=u
        self.next=None
class sll:
    def __init__(self):
        self.head=None
    def add_end(self,v):
        t=self.head
        while t.next!=None:
            t=t.next
        t.next=node(v)
    def add_beg(self,u):
        Newnode=node(u)
        t=self.head
        Newnode.next=t
        self.head=Newnode
    def find_len_ll(self):
        temp=self.head
        if self.head.next is None:
            return
        sp=self.head
        fp=self.head
        while(fp and fp.next): #fp!=None and fp.next!=None
            sp=sp.next
            fp=fp.next.next
        if fp==None:
                print("even")
        else:
                print("odd")
            
    def display(self):
        t=self.head
        s=0
        while(t!=None):
            print(t.data,end='->')
            s=s+t.data
            t=t.next
        print("sum:",s)
        
l1=sll()
l1.head=node(10)
l1.add_end(20)
l1.add_end(30)
l1.display()
l1.add_beg(234)
l1.add_end(456)
l1.display()
#l1.add_beg(134)
l1.display()
l1.find_len_ll()







