class node:
    def __init__(self,u):
        self.data=u
        self.next=None
class sll:
    def __init__(self):
        self.head=None
    def add_end(self,v):
        t=self.head
        while t.next!=None:
            t=t.next
        t.next=node(v)
    def add_beg(self,u):
        Newnode=node(u)
        t=self.head
        Newnode.next=t
        self.head=Newnode
    def reversing(self):
        a = None
        b = self.head
        while b is not None:
            c = b.next
            b.next = a
            a = b
            b = c
        self.head = a
            
    def display(self):
        t=self.head
        s=0
        while(t!=None):
            print(t.data,end='->')
            s=s+t.data
            t=t.next
        print("sum:",s)
        
l1=sll()
l1.head=node(13)
l1.add_end(11)
l1.add_end(10)
l1.display()
l1.add_beg(14)
l1.add_end(9)
l1.display()
l1.add_beg(15)
l1.display()
l1.reversing()
l1.display()

