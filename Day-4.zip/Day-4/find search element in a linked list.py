class node:
    def __init__(self,u):
        self.data=u
        self.next=None
class sll:
    def __init__(self):
        self.head=None
    def add_end(self,v):
        t=self.head
        while t.next!=None:
            t=t.next
        t.next=node(v)
    def add_beg(self,u):
        Newnode=node(u)
        t=self.head
        Newnode.next=t
        self.head=Newnode
    def search_ele(self,ele):
        temp=self.head
        while temp is not None:
            if temp.data==ele:
                print("found")
                break
            else:
                temp=temp.next
        else:
            print("not found")
        
    def display(self):
        t=self.head
        s=0
        while(t!=None):
            print(t.data,end='->')
            s=s+t.data
            t=t.next
        print("sum:",s)
        
l1=sll()
l1.head=node(10)
l1.add_end(20)
l1.add_end(30)
l1.display()
l1.add_beg(234)
l1.add_end(456)
l1.display()
l1.add_beg(134)
l1.display()
l1.search_ele(456)
l1.search_ele(1000)




