dic={}
class Node:
    def __init__(self,data):
        self.data=data
        self.left=None
        self.right=None
class Binary_tree:
    def create_node(self,data):
        return Node(data)
    def insert(self,node,data):
        if node is None:
            return self.create_node(data)
        if data<node.data:
            node.left=self.insert(node.left,data)
        else:
            node.right=self.insert(node.right,data)
        return node
    def top_view(self,root,key,level):
        if root:
            if key not in dic:
                dic[key]=[root.data,level]
            elif dic[key][1]>level:
                dic[key]=[root.data,level]
            
        
            self.top_view(root.left,key-1,level+1)
            self.top_view(root.right,key+1,level+1)
    def top_v(self,li):
        for key in sorted(dic):
            li.append(dic[key][0])
        return li
            

tree=Binary_tree()
root=tree.create_node(10)
tree.insert(root,5)
tree.insert(root,15)
tree.insert(root,2)
tree.insert(root,7)
tree.insert(root,11)
tree.insert(root,8)
tree.insert(root,9)
#tree.insert(root,18)
#tree.insert(root,16)
tree.top_view(root,0,0)
li=[]
print(tree.top_v(li))
