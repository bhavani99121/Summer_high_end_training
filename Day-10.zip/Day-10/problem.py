ip="hello:5438,car:214,book:8799,apple:2187"
words=ip.split(",")
#print(words)
li=[]
li1=[]
for i in range(len(words)):
    if words[i]==":":
        li.append(words[i:])
for i in words:
    l=i
    for j in range(len(l)):
        if l[j]==":":
            li.append(l[j+1:])
            li1.append(l[:j])
v=""
r=""
for i in range(len(li1)):
    l=len(li1[i])
    c1=str(l)
    v=li1[i]      
    for j in li:
        n=j
        n1=str(n)
        for k in range(1,l+1):
            if c1 in n1:
                r=r+v[l-1]
                break
            else:
                l=l-1
                break
    else:
        r=r+'x'
        break
print(li)
print(li1)
print(r)
        
    

