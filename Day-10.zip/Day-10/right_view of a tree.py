#printing left view nodes
#prining left subtree,every left node
class Node:
    def __init__(self,data):
        self.data=data
        self.left=None
        self.right=None
class Binary_tree:
    def create_node(self,data):
        return Node(data)
    def insert(self,node,data):
        if node is None:
            return self.create_node(data)
        if data<node.data:
            node.left=self.insert(node.left,data)
        else:
            node.right=self.insert(node.right,data)
        return node
    def right_view(self,root,c,l1):
        if root==None:
            return
        if c not in l1:
            print(root.data,c)
            l1.append(c)
        self.right_view(root.right,c+1,l1)
        self.right_view(root.left,c+1,l1)
            
        
        
        
tree=Binary_tree()
root=tree.create_node(10)
tree.insert(root,5)
tree.insert(root,15)
tree.insert(root,2)
tree.insert(root,7)
tree.insert(root,11)
tree.insert(root,20)
tree.insert(root,4)
tree.insert(root,22)
tree.insert(root,3)
l1=[]
tree.right_view(root,0,l1)








