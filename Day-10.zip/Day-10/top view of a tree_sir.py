dic={}
class Node:
    def __init__(self,data):
        self.data=data
        self.left=None
        self.right=None
class Binary_tree:
    def create_node(self,data):
        return Node(data)
    def insert(self,node,data):
        if node is None:
            return self.create_node(data)
        if data<node.data:
            node.left=self.insert(node.left,data)
        else:
            node.right=self.insert(node.right,data)
        return node
    def top_view(self,root):
        queue=[(root,0)]
        
        while queue:
            root=queue[0][0]
            if root.left is not None:
                queue.append((root.left,queue[0][1]-1))
            if root.right is not None:
                queue.append((root.right,queue[0][1]+1))
            if queue[0][1] not in dic:
                dic[queue[0][1]]=root.data
            queue.pop(0)
        for i in sorted(dic):
            print(dic[i],end=" ")
            

tree=Binary_tree()
root=tree.create_node(10)
tree.insert(root,5)
tree.insert(root,15)
tree.insert(root,2)
tree.insert(root,7)
tree.insert(root,11)
tree.insert(root,8)
tree.insert(root,9)
#tree.insert(root,18)

tree.top_view(root)


