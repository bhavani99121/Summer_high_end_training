s=input()
li1=[]
for i in s:
    if i=='*':
        li1.pop()
    else:
        li1.append(i)
print("".join(li1))
        