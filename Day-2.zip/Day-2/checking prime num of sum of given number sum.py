#take a number add all digits of a num andd check the sum value is prime or not
def notprime(num):
    n=num
    s=0
    while n:
        r=n%10
        s=s+r
        n=n//10
    if s<10:
        if s in [2,3,5,7]:
            return num
        else:
            notprime(num+1)
    else:
        notprime(s)
def primenum(num):
        if num in [2,3,5,7]:
            return num
        else:
            notprime(num)

num=int(input())
if num<10:
    print(primenum(num))
else:
    print(notprime(num))
        