inp=input() 
m=0
f=0
dic={}
for m in inp:
    if m in dic:
        dic[m]+=1
    else:
        dic[m]=1
if dic['M']==dic['F']:
    print('0')
elif dic['M']>dic['F']:
    print('male')
else:
    print('female')
    
        