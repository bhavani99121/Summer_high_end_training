def even_sum(n):
    if n==0:
        return 0
    return n+even_sum(n-2)
n=int(input())
if n%2==0:
    print(even_sum(n))
else:
    print(even_sum(n-1))