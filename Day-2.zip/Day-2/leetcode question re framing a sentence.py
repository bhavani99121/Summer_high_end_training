s="is2 sentence4 This1 a3"
words=s.split()
li=[0]*len(words)
for i in words:
    li[(int(i[-1])-1)]=i[:-1]
print(li)
print(" ".join(li))

    