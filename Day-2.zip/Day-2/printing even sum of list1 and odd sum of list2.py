#using recursion sum of even number of a list and odd numer of b list
def even_odd_sum(s1,s2,i):
    if i==len(li1):
            return (s1,s2) 
    if li1[i]%2==0:
        s1=s1+li1[i]
    if li2[i]%2!=0:
        s2=s2+li2[i]
    
    return even_odd_sum(s1,s2,i+1)

    
li1=list(map(int,input().split(" ")))
li2=list(map(int,input().split(" ")))
i,j=even_odd_sum(0,0,0)
print(i,j)

