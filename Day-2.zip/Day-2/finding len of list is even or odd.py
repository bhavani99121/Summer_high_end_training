li=list(map(int,input().split(" ")))
i=0
j=li[-1]
while(i<=j):type(id(a[0]))
    i=i+1
    j=j-1
if i>j:
    print('no')
else:
    print('yes')

    

